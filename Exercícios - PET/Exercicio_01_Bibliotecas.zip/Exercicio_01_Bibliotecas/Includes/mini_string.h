#ifndef MINI_STRING_H
#define MINI_STRING_H


void string_concatenar(char* strA, char* strB, char* strCat);

int string_comparar(char* strA, char* strB);

int string_ocorrencia(char* strA, char* strB);

#endif